import 'package:flutter/material.dart';
import 'package:notes_app/data/model/notes_model.dart';

class EventList extends StatelessWidget {
  final List<NotesModel> events;

  EventList({required this.events});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: events.length,
      itemBuilder: (context, index) {
        final event = events[index];
        return ListTile(
          title: Text(event.title),
          subtitle: Text(event.date.toLocal().toString()),
        );
      },
    );
  }
}
