import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../data/database/database_helper.dart';
import '../blocs/note_bloc.dart';
import '../blocs/note_event.dart';
import '../blocs/note_state.dart';
import 'add_notes.dart';


class CalendarPage extends StatefulWidget {
  @override
  _CalendarPageState createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  DateTime _selectedDate = DateTime.now();
  final databaseHelper = DatabaseHelper.instance;
  // final notes = await databaseHelper.getNotesByDate(DateTime.now());
  // print(notes); // Saqlangan yozuvlarni konsolga chiqaradi


  // Future<void> loadNotes() async {
  //   final notes = await databaseHelper.getNotesByDate(_selectedDate);
  //   setState(() {
  //     _notes = notes;  // _notes bu sizning ro'yxatingiz
  //   });
  // }

  @override
  void initState() {
    super.initState();
    // Sahifa yuklanganda bugungi sana bo'yicha ma'lumotlarni yuklash
    BlocProvider.of<NoteBloc>(context).add(LoadEventsByDate(_selectedDate));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calendar'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddEventPage()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Kalendar UI
          Container(
            height: 100, // Siz o'z kalendaringizni yaratishingiz kerak
            color: Colors.grey[200],
            child: Center(
              child: Text(
                'Calendar Placeholder', // Kalendarni o'zgartiring
                style: TextStyle(fontSize: 20),
              ),
            ),
          ),
          Expanded(
            child:
            BlocBuilder<NoteBloc, NoteState>(
              builder: (context, state) {
                if (state is NoteLoadInProgress) {
                  print("Loading notes..."); // Yuklanish jarayonini kuzatish
                  return Center(child: CircularProgressIndicator());
                } else if (state is NoteLoadSuccess) {
                  print("Notes loaded: ${state.notes}"); // Yuklangan ma'lumotlarni ko'rish
                  return ListView.builder(
                    itemCount: state.notes.length,
                    itemBuilder: (context, index) {
                      final note = state.notes[index];
                      return ListTile(
                        title: Text(note.title),
                        subtitle: Text(note.date.toLocal().toString().split(' ')[0]),
                      );
                    },
                  );
                } else if (state is NoteLoadFailure) {
                  print("Failed to load notes"); // Xatolik yuz berdi
                  return Center(child: Text('Failed to load events'));
                }
                return Center(child: Text('No events found'));
              },
            )
          ),
        ],
      ),
    );
  }
}
