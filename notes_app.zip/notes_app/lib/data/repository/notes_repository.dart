//
// import '../database/database_helper.dart';
// import '../model/notes_model.dart';
//
// class NotesRepository {
//   final DatabaseHelper _databaseHelper = DatabaseHelper.instance;
//
//   Future<int> insertEvent(NotesModel notesModel) async {
//     return await _databaseHelper.insert(notesModel);
//   }
//
//   Future<List<NotesModel>> getEventsByDate(DateTime date) async {
//     return await _databaseHelper.queryByDate(date);
//   }
//
//   Future<List<NotesModel>> getAllEvents() async {
//     return await _databaseHelper.queryAll();
//   }
//
//   Future<int> updateEvent(NotesModel notesModel) async {
//     return await _databaseHelper.update(notesModel);
//   }
//
//   Future<int> deleteEvent(int id) async {
//     return await _databaseHelper.delete(id);
//   }
// }
