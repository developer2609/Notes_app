import 'package:notes_app/data/model/notes_model.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final _databaseName = "events.db";
  static final _databaseVersion = 1;

  static final table = 'notes';

  static final columnId = 'id';
  static final columnTitle = 'title';
  static final columnDate = 'date';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), _databaseName);
    print("Database path: $path"); // Konsolda bazaning yo'lini tekshiring

    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $table (
        $columnId INTEGER PRIMARY KEY AUTOINCREMENT,
        $columnTitle TEXT NOT NULL,
        $columnDate TEXT NOT NULL
      )
    ''');
  }

  Future<void> insertNote(NotesModel note) async {
    final db = await database;
    await db.insert(
      table,
      note.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateNote(NotesModel note) async {
    final db = await database;
    await db.update(
      table,
      note.toMap(),
      where: '$columnId = ?',
      whereArgs: [note.id],
    );
  }

  Future<void> deleteNote(int id) async {
    final db = await database;
    await db.delete(
      table,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }
  Future<List<NotesModel>> getNotesByDate(DateTime date) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      table,
      columns: [columnId, columnTitle, columnDate], // Natijalarni ko'rish uchun ustunlarni qo'shing
    );
    print(maps); // Saqlangan ma'lumotlarni chop eting
    return List.generate(maps.length, (i) {
      return NotesModel(
        id: maps[i][columnId],
        title: maps[i][columnTitle],
        date: DateTime.parse(maps[i][columnDate]),
      );
    });
  }


// Future<List<NotesModel>> getNotesByDate(DateTime date) async {
  //   final db = await database;
  //   final List<Map<String, dynamic>> maps = await db.query(
  //     table,
  //     where: '$columnDate = ?',
  //     whereArgs: [DateFormat('yyyy-MM-dd').format(date)], // Sanani faqat yil-oy-kun formatida saqlash
  //   );
  //   return List.generate(maps.length, (i) {
  //     return NotesModel(
  //       id: maps[i][columnId],
  //       title: maps[i][columnTitle],
  //       date: DateTime.parse(maps[i][columnDate]),
  //     );
  //   });
  // }
}
