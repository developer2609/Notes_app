class NotesModel {
  final int? id;  // ID opsional bo'lishi kerak
  final String title;
  final DateTime date;
  NotesModel({ this.id, required this.title, required this.date});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'date': date.toIso8601String(),
    };
  }

  static NotesModel fromMap(Map<String, dynamic> map) {
    return NotesModel(
      id: map['id'],
      title: map['title'],
      date: DateTime.parse(map['date']),
    );
  }
}
