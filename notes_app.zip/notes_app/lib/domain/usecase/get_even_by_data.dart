//
// import '../../data/model/notes_model.dart';
// import '../../data/repository/notes_repository.dart';
//
// class GetEventsByDate {
//   final NotesRepository repository;
//
//   GetEventsByDate(this.repository);
//
//   Future<List<NotesModel>> execute(DateTime date) async {
//     return await repository.getEventsByDate(date);
//   }
// }
