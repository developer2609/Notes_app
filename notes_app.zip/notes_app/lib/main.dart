import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:notes_app/presentation/blocs/note_bloc.dart';
import 'package:notes_app/presentation/pages/home_page.dart';
import 'data/database/database_helper.dart';


void main() {

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // final DatabaseHelper databaseHelper;

  // MyApp({required this.databaseHelper});

  @override
  Widget build(BuildContext context) {
    final databaseHelper = DatabaseHelper.instance;

    return BlocProvider(
      create: (context) => NoteBloc(databaseHelper),
      child: MaterialApp(
        title: 'Event Calendar',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: CalendarPage(),
      ),
    );
  }
}
